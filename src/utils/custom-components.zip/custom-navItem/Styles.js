import styled from "styled-components";

export const StaticNavItem = styled.li`
  list-style: none;
  padding: 10px 15px;
  font-size: 14px;
  font-weight: bold;
  text-transform: uppercase;
  color: #95a5a6;
  border-left: 4px solid orange;
  cursor: default;

  .static-text {
    display: block;
    pointer-events: none;
  }
`;

export const DropdownContainer = styled.div`
  .dropdown-toggle {
    border-radius: 5px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 15px;
    cursor: pointer;
    transition: background-color 0.3s;

    &:hover {
      background-color: #f3f3f3;
    }

    &.active {
      background-color: #f3f3f3;
      color: #000;
    }

    .icon-container {
      margin-right: 10px;

      .item-icon {
        font-size: 18px;
      }
    }

    .default-text {
      font-size: 16px;
      flex: 1;
      text-align: left;
    }
  }
`;

export const DropdownContent = styled.div`
  overflow: hidden;
  max-height: ${(props) => (props.isOpen ? "500px" : "0")};
  transition: max-height 0.3s ease-in-out, padding 0.3s ease-in-out;
  padding: ${(props) => (props.isOpen ? "10px 15px" : "0 15px")};
  background-color: #d9d9d9;
  border-left: 2px solid #4dbfa7;

  .dropdown-item {
    padding: 10px 0;

    a {
      display: flex;
      align-items: center;
      text-decoration: none;
      color: inherit;
      transition: background-color 0.3s, color 0.3s;

      &.active {
        background-color: #f3f3f3;
        color: #fff;
        border-radius: 5px;
      }

      .icon-container {
        margin-right: 10px;

        .item-icon {
          font-size: 16px;
        }
      }

      .default-text {
        font-size: 14px;
        text-align: left;
      }

      &:hover {
        background-color: #f3f3f3;
      }
    }
  }
`;

export const NavItem = styled.li`
  list-style: none;

  .nav-link {
    display: flex;
    align-items: center;
    padding: 10px 15px;
    text-decoration: none;
    color: #000;
    border-radius: 5px;
    transition: background-color 0.3s, color 0.3s;

    &:hover {
      background-color: #f3f3f3;
    }

    &.active {
      background-color: #f3f3f3;
      color: #000;
    }

    .icon-container {
      margin-right: 10px;

      .item-icon {
        font-size: 18px;
      }
    }

    .item-name {
      font-size: 16px;
    }
  }
`;
