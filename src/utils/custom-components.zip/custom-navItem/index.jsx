import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import {
  DropdownContainer,
  DropdownContent,
  StaticNavItem,
  NavItem,
} from "./Styles";

export default function CustomNavItem(props) {
  const [openDropdown, setOpenDropdown] = useState(null);

  const handleDropdownToggle = (index) => {
    setOpenDropdown((prev) => (prev === index ? null : index));
  };

  return props.sidebarMenu.map((menu, index) => {
    if (menu?.static) {
      // Static category item
      return (
        <>
          <span></span>
          {!props.isCollapsed && (
            <StaticNavItem key={menu.name}>
              <span className="static-text fade">{menu.name}</span>
            </StaticNavItem>
          )}
        </>
      );
    } else if (menu?.children) {
      // Dropdown menu
      return (
        <DropdownContainer key={menu.name}>
          <div
            className={`dropdown-toggle ${
              openDropdown === index ? "active" : ""
            }`}
            onClick={() => handleDropdownToggle(index)}
          >
            <div className="icon-container">
              <i className="item-icon">{menu.icon}</i>
            </div>
            {!props.isCollapsed && (
              <span className="default-text fade">{menu.name}</span>
            )}
          </div>
          <DropdownContent isOpen={openDropdown === index}>
            {menu.children.map((child) => (
              <div className="dropdown-item" key={child.name}>
                <NavLink
                  to={child.link}
                  className={({ isActive }) =>
                    isActive ? "nav-link active" : "nav-link"
                  }
                >
                  {child?.icon && (
                    <div className="icon-container">
                      <i className="item-icon">{child.icon}</i>
                    </div>
                  )}
                  {!props.isCollapsed && (
                    <span className="default-text fade">{child.name}</span>
                  )}
                </NavLink>
              </div>
            ))}
          </DropdownContent>
        </DropdownContainer>
      );
    } else if(props?.permissions?.includes(menu?.permission)) {
      // Regular clickable item
      return (
        <NavItem key={menu.name}>
          <NavLink
            to={menu.link}
            className={({ isActive }) =>
              isActive ? "nav-link active" : "nav-link"
            }
          >
            <i className="item-icon">{menu.icon}</i>
            {!props.isCollapsed && (
              <span className="item-name fade">{menu.name}</span>
            )}
          </NavLink>
        </NavItem>
      );
    }
  });
}
