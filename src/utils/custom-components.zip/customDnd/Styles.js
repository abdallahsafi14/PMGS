import styled from "styled-components";

export const Styles = styled.div`
  .card{
    display: flex;
    align-items: center;
  }
`